//
//  AppDelegate.h
//  DevDiv_CollectionView_CircleLayout_Demo
//
//  Created by BeyondVincent on 12-7-3.
//  Copyright (c) 2012年 DevDiv. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
